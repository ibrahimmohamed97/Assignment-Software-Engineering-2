<form method="POST" name="test" action="Index1.php">
  <input type="submit" name="Submit" class="Style9" value="By Name" />
</form>

<form method="POST" name="test" action="Index2.php">
  <input type="submit" name="Submit" class="Style9" value="By Id" />
</form>


<form method="POST" name="test" action="Index3.php">
  <input type="submit" name="Submit" class="Style9" value="By geographic coordinates" />
</form>

<form method="POST" name="test" action="Index4.php">
  <input type="submit" name="Submit" class="Style9" value="By Zip Code" />
</form>

<form method="POST" name="test" action="Index5.php">
  <input type="submit" name="Submit" class="Style9" value="By Rectangle Zone " />
</form>

<form method="POST" name="test" action="Index6.php">
  <input type="submit" name="Submit" class="Style9" value="By Cycle Zone " />
</form>

<form method="POST" name="test" action="Index7.php">
  <input type="submit" name="Submit" class="Style9" value="By  IDS Groups" />
</form>