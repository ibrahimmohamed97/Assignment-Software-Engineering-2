<!DOCTYPE html>
<html>
<head><title>Weather Report Using api </title>

</head>

<body>

<center>

	</center>
	<center><br><br>
		<form method="GET" action="geo.php">
		<h1>Type the Coordinates of Country</h1>
		<br><p>For Example 123 and 134,in</p>
			<input type="text" name="q" required>
            <input type="text" name="w" required>
			<input type="submit" name="submit">
		</form>
	</center>
</body>
</html>