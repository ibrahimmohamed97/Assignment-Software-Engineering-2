<!DOCTYPE html>
<html>
<head><title>Weather Report Using api </title>

</head>

<body>

<center>

	</center>
	<center><br><br>
		<form method="GET" action="zip.php">
		<h1>Type the Zip Code of Country</h1>
		<br><p>For Example 123134,in</p>
			<input type="text" name="q" required>
			<input type="submit" name="submit">
		</form>
	</center>
</body>
</html>