<!DOCTYPE html>
<html>
<head><title>Weather Report Using api </title>

</head>

<body>

<center>

	</center>
	<center><br><br>
		<form method="GET" action="ids.php">
		<h1>Type the rectangle zone of Country</h1>
		<br><p>For Example 524901,703448,2643743,in</p>
			<input type="text" name="q" required>
			<input type="submit" name="submit">
		</form>
	</center>
</body>
</html>s